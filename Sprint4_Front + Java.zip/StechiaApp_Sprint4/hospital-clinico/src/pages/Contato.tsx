import React from 'react';
import ContactForm from '../components/ContactForm';

const Contato: React.FC = () => {
  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <section className="py-8 sm:py-12 md:py-16 lg:py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12 md:mb-16">
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-hospital-blue mb-4">
              Entre em Contato
            </h1>
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-600 max-w-2xl mx-auto">
              Estamos à disposição para melhor atendê-lo
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 sm:gap-10 md:gap-12">
            {/* Informações de Contato */}
            <div className="space-y-6 sm:space-y-8">
              <div className="flex items-start space-x-3 sm:space-x-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-hospital-blue text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-map-marker-alt text-sm sm:text-base"></i>
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-hospital-blue mb-2">Endereço</h3>
                  <p className="text-sm sm:text-base text-gray-600">
                    Av. Dr. Enéas de Carvalho Aguiar, 255<br />
                    05403-000<br />
                    São Paulo - Brasil
                  </p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 sm:space-x-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-hospital-blue text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-phone-alt text-sm sm:text-base"></i>
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-hospital-blue mb-2">Telefones</h3>
                  <p className="text-sm sm:text-base text-gray-600">(0xx11) 2661-0000</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 sm:space-x-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-hospital-blue text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-envelope text-sm sm:text-base"></i>
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-hospital-blue mb-2">Email</h3>
                  <p className="text-sm sm:text-base text-gray-600 break-all">contato@hospitalclinico.com.br</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 sm:space-x-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-hospital-blue text-white rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="fas fa-clock text-sm sm:text-base"></i>
                </div>
                <div>
                  <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-hospital-blue mb-2">Horário de Funcionamento</h3>
                  <p className="text-sm sm:text-base text-gray-600">
                    Funcionamento 24 horas por dia, indo em busca do seu bem-estar
                  </p>
                </div>
              </div>
            </div>
            
            {/* Formulário de Contato */}
            <ContactForm />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contato;






