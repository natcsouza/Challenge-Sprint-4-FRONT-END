import React, { useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { specialties } from '../data/mockData';
import Button from '../components/Button';
import { useToast } from '../hooks/useToast';
import ToastContainer from '../components/ToastContainer';

const EspecialidadeDetalhes: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toasts, error: showError, removeToast } = useToast();
  
  const especialidade = specialties.find(s => s.id === id);

  useEffect(() => {
    if (!especialidade && id) {
      showError('Especialidade não encontrada. Redirecionando...');
      const timer = setTimeout(() => {
        navigate('/especialidades', { replace: true });
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [especialidade, id, navigate, showError]);

  if (!especialidade) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center bg-gray-50">
        <ToastContainer toasts={toasts} onRemove={removeToast} />
        <div className="text-center px-4">
          <i className="fas fa-exclamation-triangle text-6xl text-yellow-500 mb-4"></i>
          <h1 className="text-2xl md:text-3xl font-bold text-gray-800 mb-4">
            Especialidade não encontrada
          </h1>
          <p className="text-gray-600 mb-6">
            A especialidade que você está procurando não existe ou foi removida.
          </p>
          <Button onClick={() => navigate('/especialidades')} variant="primary" size="large">
            <i className="fas fa-arrow-left mr-2"></i>
            Voltar para Especialidades
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <ToastContainer toasts={toasts} onRemove={removeToast} />
      <section className="py-8 md:py-12 lg:py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            {/* Botão de voltar */}
            <Button 
              onClick={() => navigate('/especialidades')} 
              variant="secondary" 
              className="mb-4 md:mb-8"
            >
              <i className="fas fa-arrow-left mr-2"></i>
              Voltar para Especialidades
            </Button>

            {/* Conteúdo da especialidade */}
            <div className="bg-white rounded-lg shadow-lg overflow-hidden">
              <img 
                src={especialidade.image} 
                alt={especialidade.title}
                className="w-full h-48 sm:h-64 md:h-80 object-cover"
              />
              <div className="p-4 sm:p-6 md:p-8">
                <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-hospital-blue mb-4">
                  {especialidade.title}
                </h1>
                <p className="text-gray-600 text-base sm:text-lg md:text-xl leading-relaxed mb-6">
                  {especialidade.description}
                </p>
                
                {/* Informações adicionais baseadas no ID */}
                <div className="bg-gray-50 p-4 sm:p-6 rounded-lg">
                  <h2 className="text-lg sm:text-xl md:text-2xl font-semibold text-hospital-blue mb-4">
                    Informações Detalhadas
                  </h2>
                  {id === '1' && (
                    <div className="space-y-2 text-sm sm:text-base">
                      <p><strong className="text-hospital-blue">Horário de Atendimento:</strong> Segunda a Sexta, 8h às 18h</p>
                      <p><strong className="text-hospital-blue">Médicos Especialistas:</strong> 3 cardiologistas certificados</p>
                      <p><strong className="text-hospital-blue">Exames Disponíveis:</strong> Ecocardiograma, Teste Ergométrico, Holter</p>
                    </div>
                  )}
                  {id === '2' && (
                    <div className="space-y-2 text-sm sm:text-base">
                      <p><strong className="text-hospital-blue">Horário de Atendimento:</strong> Segunda a Sexta, 7h às 19h</p>
                      <p><strong className="text-hospital-blue">Médicos Especialistas:</strong> 2 ortopedistas especializados</p>
                      <p><strong className="text-hospital-blue">Procedimentos:</strong> Cirurgias, Fisioterapia, Infiltrações</p>
                    </div>
                  )}
                  {id === '3' && (
                    <div className="space-y-2 text-sm sm:text-base">
                      <p><strong className="text-hospital-blue">Horário de Atendimento:</strong> Segunda a Sábado, 8h às 17h</p>
                      <p><strong className="text-hospital-blue">Médicos Especialistas:</strong> 4 pediatras certificados</p>
                      <p><strong className="text-hospital-blue">Serviços:</strong> Consultas, Vacinas, Acompanhamento do Desenvolvimento</p>
                    </div>
                  )}
                </div>

                {/* Botões de ação */}
                <div className="flex flex-col sm:flex-row gap-4 mt-6 md:mt-8">
                  <Button 
                    onClick={() => navigate('/contato')} 
                    variant="primary"
                    className="flex-1"
                    size="large"
                  >
                    <i className="fas fa-calendar-alt mr-2"></i>
                    Agendar Consulta
                  </Button>
                  <Button 
                    onClick={() => navigate('/equipe')} 
                    variant="secondary"
                    className="flex-1"
                    size="large"
                  >
                    <i className="fas fa-users mr-2"></i>
                    Conhecer Equipe
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default EspecialidadeDetalhes;
