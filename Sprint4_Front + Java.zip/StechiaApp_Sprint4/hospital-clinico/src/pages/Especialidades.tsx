import React from 'react';
import { useNavigate } from 'react-router-dom';
import Card from '../components/Card';
import { specialties } from '../data/mockData';

const Especialidades: React.FC = () => {
  const navigate = useNavigate();

  const handleSpecialtyClick = (id: string) => {
    navigate(`/especialidades/${id}`);
  };

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <section className="py-8 sm:py-12 md:py-16 lg:py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8 sm:mb-12 md:mb-16">
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-hospital-blue mb-4">
              Nossas Especialidades
            </h1>
            <p className="text-sm sm:text-base md:text-lg lg:text-xl text-gray-600 max-w-2xl mx-auto">
              Cuidado integral para todas as fases da vida
            </p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 md:gap-8">
            {specialties.map((specialty) => (
              <Card key={specialty.id} hover={true}>
                <div 
                  onClick={() => handleSpecialtyClick(specialty.id)}
                  className="cursor-pointer"
                >
                  <img 
                    src={specialty.image} 
                    alt={specialty.title}
                    className="w-full h-40 sm:h-48 md:h-56 object-cover"
                  />
                  <div className="p-4 sm:p-5 md:p-6">
                    <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-hospital-blue mb-2 sm:mb-3">
                      {specialty.title}
                    </h3>
                    <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-3 sm:mb-4">
                      {specialty.description}
                    </p>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSpecialtyClick(specialty.id);
                      }}
                      className="text-sm sm:text-base text-hospital-orange font-semibold hover:text-hospital-blue transition-colors"
                    >
                      Ver Detalhes →
                    </button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Especialidades;






