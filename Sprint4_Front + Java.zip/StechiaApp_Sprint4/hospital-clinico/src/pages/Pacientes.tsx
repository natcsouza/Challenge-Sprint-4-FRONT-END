import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiService } from '../services/api';
import { Paciente, ApiResponse, PaginatedResponse } from '../types';
import { useToast } from '../hooks/useToast';
import ToastContainer from '../components/ToastContainer';
import Button from '../components/Button';

const Pacientes: React.FC = () => {
  const [pacientes, setPacientes] = useState<Paciente[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const { toasts, success, error: showError, removeToast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    loadPacientes();
  }, []);

  const loadPacientes = async () => {
    try {
      setLoading(true);
      setError(null);
      const response: ApiResponse<PaginatedResponse<Paciente>> = await apiService.getPacientes();

      if (response.success && response.data) {
        // ✅ Compatível com retorno simples (array) e paginado (content)
        const data = Array.isArray(response.data)
          ? response.data
          : response.data.content || [];
        setPacientes(data);
      } else {
        const errorMsg =
          response.message ||
          'API não disponível. A lista estará vazia até que a API seja configurada.';
        console.warn(errorMsg);
        setPacientes([]);
        if (!errorMsg.includes('Failed to fetch') && !errorMsg.includes('API não disponível')) {
          setError(errorMsg);
        }
      }
    } catch (err) {
      console.warn('Erro ao conectar com API:', err);
      setPacientes([]);
      setError(null);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id: string | number) => {
    if (!window.confirm('Tem certeza que deseja excluir este paciente?')) {
      return;
    }

    try {
      const response = await apiService.deletePaciente(id);

      if (response.success) {
        success('Paciente excluído com sucesso!');
        loadPacientes();
      } else {
        showError(response.message || 'Erro ao excluir paciente');
      }
    } catch (err) {
      showError('Erro ao excluir paciente');
    }
  };

  const handleEdit = (id: string | number) => {
    navigate(`/pacientes/${id}/editar`);
  };

  if (loading) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-4xl text-hospital-blue mb-4"></i>
          <p className="text-gray-600">Carregando pacientes...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      <section className="py-8 px-4">
        <div className="container mx-auto">
          <div className="flex flex-col sm:flex-row justify-between items-center mb-8 gap-4">
            <div>
              <h1 className="text-3xl font-bold text-hospital-blue mb-2">
                Gerenciar Pacientes
              </h1>
              <p className="text-gray-600">
                Lista de pacientes cadastrados no sistema
              </p>
            </div>
            <Button
              onClick={() => navigate('/pacientes/novo')}
              variant="primary"
              size="large"
            >
              <i className="fas fa-plus mr-2"></i>
              Novo Paciente
            </Button>
          </div>

          {error && !error.includes('API não disponível') && (
            <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
              <p>{error}</p>
            </div>
          )}

          {pacientes.length === 0 ? (
            <div className="bg-white rounded-lg shadow p-8 text-center">
              <i className="fas fa-users text-4xl text-gray-400 mb-4"></i>
              <p className="text-gray-600 mb-4">Nenhum paciente cadastrado</p>
              <Button
                onClick={() => navigate('/pacientes/novo')}
                variant="primary"
              >
                Cadastrar Primeiro Paciente
              </Button>
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-hospital-blue text-white">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider">
                        Nome
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden md:table-cell">
                        CPF
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden lg:table-cell">
                        Email
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium uppercase tracking-wider hidden sm:table-cell">
                        Status
                      </th>
                      <th className="px-4 py-3 text-right text-xs font-medium uppercase tracking-wider">
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {pacientes.map((paciente) => (
                      <tr key={paciente.id} className="hover:bg-gray-50">
                        <td className="px-4 py-4 whitespace-nowrap">
                          <div className="text-sm font-medium text-gray-900">
                            {paciente.nome}
                          </div>
                          <div className="text-sm text-gray-500 md:hidden">
                            {paciente.cpf}
                          </div>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500 hidden md:table-cell">
                          {paciente.cpf}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500 hidden lg:table-cell">
                          {paciente.email}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap hidden sm:table-cell">
                          <span
                            className={`px-2 py-1 text-xs font-semibold rounded-full ${
                              paciente.status === 'ativo'
                                ? 'bg-green-100 text-green-800'
                                : paciente.status === 'inativo'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            {paciente.status || 'ativo'}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap text-right text-sm font-medium">
                          <div className="flex justify-end gap-2">
                            <button
                              onClick={() => handleEdit(paciente.id)}
                              className="text-hospital-blue hover:text-hospital-orange transition-colors"
                              title="Editar"
                            >
                              <i className="fas fa-edit"></i>
                            </button>
                            <button
                              onClick={() => handleDelete(paciente.id)}
                              className="text-red-600 hover:text-red-800 transition-colors"
                              title="Excluir"
                            >
                              <i className="fas fa-trash"></i>
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default Pacientes;
