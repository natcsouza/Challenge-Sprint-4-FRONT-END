import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { apiService } from '../services/api';
import { Paciente, ApiResponse } from '../types';
import { useToast } from '../hooks/useToast';
import ToastContainer from '../components/ToastContainer';
import Button from '../components/Button';

interface PacienteFormData {
  nome: string;
  cpf: string;
  email: string;
  telefone: string;
  dataNascimento: string;
  endereco: {
    cep: string;
    logradouro: string;
    numero: string;
    complemento?: string;
    bairro: string;
    cidade: string;
    estado: string;
  };
  status: 'ativo' | 'inativo' | 'pendente';
  convenio?: string;
}

const PacienteForm: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isEditing = !!id;
  const { toasts, success, error: showError, removeToast } = useToast();
  const [loading, setLoading] = useState<boolean>(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
  } = useForm<PacienteFormData>({
    defaultValues: {
      status: 'ativo',
      endereco: {
        cep: '',
        logradouro: '',
        numero: '',
        complemento: '',
        bairro: '',
        cidade: '',
        estado: '',
      },
    },
  });

  useEffect(() => {
    if (isEditing && id) {
      loadPaciente();
    }
  }, [id, isEditing]);

  const loadPaciente = async () => {
    try {
      setLoading(true);
      const response: ApiResponse<Paciente> = await apiService.getPacienteById(id!);

      if (response.success && response.data) {
        const paciente = response.data;
        reset({
          nome: paciente.nome,
          cpf: paciente.cpf,
          email: paciente.email,
          telefone: paciente.telefone,
          dataNascimento: paciente.dataNascimento.split('T')[0],
          endereco: paciente.endereco,
          status: paciente.status as 'ativo' | 'inativo' | 'pendente',
          convenio: paciente.convenio,
        });
      } else {
        // Se API não disponível, não mostra erro crítico ao editar
        if (!response.message?.includes('Failed to fetch') && !response.message?.includes('conectar')) {
          showError(response.message || 'Erro ao carregar paciente');
        }
        // Se for erro de API não disponível, apenas volta sem mostrar erro
        if (response.message?.includes('Failed to fetch') || response.message?.includes('conectar')) {
          console.warn('API não disponível para edição');
        } else {
          navigate('/pacientes');
        }
      }
    } catch (err) {
      // Tratamento silencioso para erros de conexão
      const errorMsg = err instanceof Error ? err.message : 'Erro desconhecido';
      if (!errorMsg.includes('Failed to fetch') && !errorMsg.includes('conectar')) {
        showError('Erro ao carregar paciente');
        navigate('/pacientes');
      }
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async (data: PacienteFormData) => {
    try {
      setLoading(true);
      let response: ApiResponse<Paciente>;

      if (isEditing && id) {
        response = await apiService.updatePaciente(id, data);
      } else {
        response = await apiService.createPaciente(data);
      }

      if (response.success) {
        success(
          isEditing
            ? 'Paciente atualizado com sucesso!'
            : 'Paciente cadastrado com sucesso!'
        );
        setTimeout(() => {
          navigate('/pacientes');
        }, 1500);
      } else {
        showError(response.message || 'Erro ao salvar paciente');
      }
    } catch (err) {
      showError('Erro ao salvar paciente');
    } finally {
      setLoading(false);
    }
  };

  const handleCepChange = async (cep: string) => {
    if (cep.length === 8) {
      try {
        const response = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
        const data = await response.json();

        if (!data.erro) {
          setValue('endereco.logradouro', data.logradouro || '');
          setValue('endereco.bairro', data.bairro || '');
          setValue('endereco.cidade', data.localidade || '');
          setValue('endereco.estado', data.uf || '');
        }
      } catch (err) {
        // Silenciosamente falha se a API do CEP não funcionar
      }
    }
  };

  if (loading && isEditing) {
    return (
      <div className="pt-20 min-h-screen flex items-center justify-center">
        <div className="text-center">
          <i className="fas fa-spinner fa-spin text-4xl text-hospital-blue mb-4"></i>
          <p className="text-gray-600">Carregando dados do paciente...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-20 min-h-screen bg-gray-50">
      <ToastContainer toasts={toasts} onRemove={removeToast} />

      <section className="py-8 px-4">
        <div className="container mx-auto max-w-4xl">
          <div className="mb-8">
            <Button
              onClick={() => navigate('/pacientes')}
              variant="secondary"
              className="mb-4"
            >
              <i className="fas fa-arrow-left mr-2"></i>
              Voltar
            </Button>
            <h1 className="text-3xl font-bold text-hospital-blue">
              {isEditing ? 'Editar Paciente' : 'Novo Paciente'}
            </h1>
          </div>

          <div className="bg-white rounded-lg shadow-lg p-6 md:p-8">
            <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
              {/* Dados Básicos */}
              <div>
                <h2 className="text-xl font-semibold text-hospital-blue mb-4">
                  Dados Básicos
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Nome Completo *
                    </label>
                    <input
                      {...register('nome', { required: 'Nome é obrigatório' })}
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.nome && (
                      <p className="text-red-500 text-sm mt-1">{errors.nome.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      CPF *
                    </label>
                    <input
                      {...register('cpf', {
                        required: 'CPF é obrigatório',
                        pattern: {
                          value: /^\d{11}$/,
                          message: 'CPF deve conter 11 dígitos',
                        },
                      })}
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.cpf && (
                      <p className="text-red-500 text-sm mt-1">{errors.cpf.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Email *
                    </label>
                    <input
                      {...register('email', {
                        required: 'Email é obrigatório',
                        pattern: {
                          value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                          message: 'Email inválido',
                        },
                      })}
                      type="email"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.email && (
                      <p className="text-red-500 text-sm mt-1">{errors.email.message}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Telefone *
                    </label>
                    <input
                      {...register('telefone', { required: 'Telefone é obrigatório' })}
                      type="tel"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.telefone && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.telefone.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Data de Nascimento *
                    </label>
                    <input
                      {...register('dataNascimento', {
                        required: 'Data de nascimento é obrigatória',
                      })}
                      type="date"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.dataNascimento && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.dataNascimento.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Status *
                    </label>
                    <select
                      {...register('status', { required: 'Status é obrigatório' })}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    >
                      <option value="ativo">Ativo</option>
                      <option value="inativo">Inativo</option>
                      <option value="pendente">Pendente</option>
                    </select>
                    {errors.status && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.status.message}
                      </p>
                    )}
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Convênio
                    </label>
                    <input
                      {...register('convenio')}
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                  </div>
                </div>
              </div>

              {/* Endereço */}
              <div>
                <h2 className="text-xl font-semibold text-hospital-blue mb-4">
                  Endereço
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      CEP *
                    </label>
                    <input
                      {...register('endereco.cep', {
                        required: 'CEP é obrigatório',
                        onChange: (e) => handleCepChange(e.target.value),
                      })}
                      type="text"
                      maxLength={8}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.endereco?.cep && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.endereco.cep.message}
                      </p>
                    )}
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Logradouro *
                    </label>
                    <input
                      {...register('endereco.logradouro', {
                        required: 'Logradouro é obrigatório',
                      })}
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.endereco?.logradouro && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.endereco.logradouro.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Número *
                    </label>
                    <input
                      {...register('endereco.numero', {
                        required: 'Número é obrigatório',
                      })}
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.endereco?.numero && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.endereco.numero.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Complemento
                    </label>
                    <input
                      {...register('endereco.complemento')}
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Bairro *
                    </label>
                    <input
                      {...register('endereco.bairro', {
                        required: 'Bairro é obrigatório',
                      })}
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.endereco?.bairro && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.endereco.bairro.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Cidade *
                    </label>
                    <input
                      {...register('endereco.cidade', {
                        required: 'Cidade é obrigatória',
                      })}
                      type="text"
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue"
                    />
                    {errors.endereco?.cidade && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.endereco.cidade.message}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">
                      Estado *
                    </label>
                    <input
                      {...register('endereco.estado', {
                        required: 'Estado é obrigatório',
                        maxLength: 2,
                      })}
                      type="text"
                      maxLength={2}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-hospital-blue uppercase"
                    />
                    {errors.endereco?.estado && (
                      <p className="text-red-500 text-sm mt-1">
                        {errors.endereco.estado.message}
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-end pt-4">
                <Button
                  type="button"
                  onClick={() => navigate('/pacientes')}
                  variant="secondary"
                  size="large"
                >
                  Cancelar
                </Button>
                <Button
                  type="submit"
                  variant="primary"
                  size="large"
                  disabled={loading}
                >
                  {loading ? (
                    <>
                      <i className="fas fa-spinner fa-spin mr-2"></i>
                      Salvando...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save mr-2"></i>
                      {isEditing ? 'Atualizar' : 'Cadastrar'}
                    </>
                  )}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </section>
    </div>
  );
};

export default PacienteForm;

