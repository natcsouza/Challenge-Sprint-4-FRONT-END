import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from './Button';

const Hero: React.FC = () => {
  const [displayedText, setDisplayedText] = useState('');
  const fullText = 'Cuidando da sua saúde com excelência';
  const navigate = useNavigate();

  useEffect(() => {
    let index = 0;
    const timer = setInterval(() => {
      if (index < fullText.length) {
        setDisplayedText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(timer);
      }
    }, 60);

    return () => clearInterval(timer);
  }, []);

  return (
    <section 
      className="relative min-h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `linear-gradient(rgba(0, 90, 106, 0.8), rgba(70, 128, 139, 0.8)), url('https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80')`
      }}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
        <h1 className="text-3xl xs:text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-4 sm:mb-6 leading-tight">
          {displayedText}
          <span className="animate-pulse">|</span>
        </h1>
        <p className="text-base sm:text-lg md:text-xl lg:text-2xl mb-6 sm:mb-8 max-w-3xl mx-auto opacity-90 px-4">
          Tecnologia de ponta, profissionais qualificados e atendimento humanizado para sua melhor experiência em saúde.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 justify-center px-4">
          <Button 
            variant="primary" 
            size="large" 
            className="w-full sm:w-auto text-sm sm:text-base"
            onClick={() => navigate('/contato')}
          >
            <i className="fas fa-calendar-alt mr-2"></i>
            Marque sua consulta
          </Button>
          <Button 
            variant="secondary" 
            size="large" 
            className="w-full sm:w-auto text-sm sm:text-base"
            onClick={() => navigate('/especialidades')}
          >
            <i className="fas fa-search mr-2"></i>
            Conheça nossos serviços
          </Button>
        </div>
      </div>
    </section>
  );
};

export default Hero;

