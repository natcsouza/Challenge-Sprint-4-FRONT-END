import React, { useEffect } from 'react';
import { Feedback, FeedbackType } from '../types';

interface ToastProps extends Feedback {
  onClose: () => void;
}

const Toast: React.FC<ToastProps> = ({ type, message, duration = 5000, onClose }) => {
  useEffect(() => {
    if (duration > 0) {
      const timer = setTimeout(() => {
        onClose();
      }, duration);

      return () => clearTimeout(timer);
    }
  }, [duration, onClose]);

  const getBgColor = (): string => {
    switch (type) {
      case 'success':
        return 'bg-green-500';
      case 'error':
        return 'bg-red-500';
      case 'warning':
        return 'bg-yellow-500';
      case 'info':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  const getIcon = (): string => {
    switch (type) {
      case 'success':
        return 'fa-check-circle';
      case 'error':
        return 'fa-exclamation-circle';
      case 'warning':
        return 'fa-exclamation-triangle';
      case 'info':
        return 'fa-info-circle';
      default:
        return 'fa-bell';
    }
  };

  return (
    <div
      className={`${getBgColor()} text-white px-6 py-4 rounded-lg shadow-lg flex items-center justify-between min-w-[300px] max-w-md animate-slide-in`}
    >
      <div className="flex items-center space-x-3">
        <i className={`fas ${getIcon()} text-xl`}></i>
        <p className="font-semibold">{message}</p>
      </div>
      <button
        onClick={onClose}
        className="ml-4 text-white hover:text-gray-200 transition-colors"
        aria-label="Fechar"
      >
        <i className="fas fa-times"></i>
      </button>
    </div>
  );
};

export default Toast;

