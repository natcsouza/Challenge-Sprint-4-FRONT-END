// Tipos Básicos (number, string, boolean, object)
export type ID = number | string;
export type Status = 'ativo' | 'inativo' | 'pendente' | 'cancelado';
export type Priority = 'baixa' | 'media' | 'alta' | 'urgente';

// Union Types
export type UserRole = 'admin' | 'medico' | 'paciente' | 'recepcionista';
export type AppointmentStatus = 'agendada' | 'confirmada' | 'cancelada' | 'concluida' | 'em_andamento';
export type PaymentMethod = 'dinheiro' | 'cartao' | 'convenio' | 'pix';

// Intersection Types
export interface BaseEntity {
  id: ID;
  createdAt: string;
  updatedAt: string;
}

export interface Timestamped {
  createdBy?: string;
  updatedBy?: string;
}

export interface Identifiable {
  id: ID;
  name: string;
}

// Interface com Intersection
export type EntityWithTimestamps = BaseEntity & Timestamped;

// Interfaces
export interface TeamMember extends Identifiable {
  id: string;
  name: string;
  role: string;
  rm: string;
  image: string;
  linkedin?: string;
  github?: string;
}

export interface Specialty extends Identifiable {
  id: string;
  title: string;
  description: string;
  image: string;
  status?: Status;
}

export interface FAQ {
  id: string;
  question: string;
  answer: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  subject: string;
  message: string;
}

export interface NavItem {
  id: string;
  label: string;
  href: string;
  isButton?: boolean;
}

// Interfaces para API - Paciente (CRUD)
export interface Paciente extends BaseEntity, Timestamped {
  nome: string;
  cpf: string;
  email: string;
  telefone: string;
  dataNascimento: string;
  endereco: Endereco;
  status: Status;
  convenio?: string;
}

export interface Endereco {
  cep: string;
  logradouro: string;
  numero: string;
  complemento?: string;
  bairro: string;
  cidade: string;
  estado: string;
}

// Interfaces para API - Consulta (CRUD)
export interface Consulta extends BaseEntity, Timestamped {
  pacienteId: ID;
  especialidadeId: ID;
  medicoId?: ID;
  dataHora: string;
  status: AppointmentStatus;
  observacoes?: string;
  valor?: number;
  formaPagamento?: PaymentMethod;
}

// Interfaces para API - Especialidade (CRUD)
export interface EspecialidadeAPI extends BaseEntity {
  nome: string;
  descricao: string;
  valorConsulta: number;
  tempoConsulta: number; // em minutos
  status: Status;
}

// Interface para resposta da API
export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  message?: string;
  errors?: string[];
}

// Interface para paginação
export interface PaginatedResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number;
}

// Tipo para parâmetros de query
export interface QueryParams {
  page?: number;
  size?: number;
  sort?: string;
  search?: string;
  status?: Status;
}

// Union Type para métodos HTTP
export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

// Tipo para configuração de requisição
export interface RequestConfig {
  method: HttpMethod;
  headers?: Record<string, string>;
  body?: object;
  params?: QueryParams;
}

// Intersection Type para entidades com validação
export interface Validatable {
  validate(): boolean;
  getErrors(): string[];
}

export type ValidatedEntity<T> = T & Validatable;

// Tipo para feedback de ações
export type FeedbackType = 'success' | 'error' | 'warning' | 'info';

export interface Feedback {
  type: FeedbackType;
  message: string;
  duration?: number;
}

// Union Type para tamanhos de tela (responsividade)
export type ScreenSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
