import { Routes, Route, Navigate } from 'react-router-dom';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Especialidades from './pages/Especialidades';
import Equipe from './pages/Equipe';
import FAQ from './pages/FAQ';
import Contato from './pages/Contato';
import Solucao from './pages/Solucao';
import EspecialidadeDetalhes from './pages/EspecialidadeDetalhes';
import NotFound from './pages/NotFound';
import Pacientes from './pages/Pacientes';
import PacienteForm from './pages/PacienteForm';

function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow pt-16">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/especialidades" element={<Especialidades />} />
          <Route path="/especialidades/:id" element={<EspecialidadeDetalhes />} />
          <Route path="/equipe" element={<Equipe />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/contato" element={<Contato />} />
          <Route path="/solucao" element={<Solucao />} />
          
          {/* Rotas CRUD - Pacientes */}
          <Route path="/pacientes" element={<Pacientes />} />
          <Route path="/pacientes/novo" element={<PacienteForm />} />
          <Route path="/pacientes/:id/editar" element={<PacienteForm />} />
          
          {/* Redirecionamento para home em caso de rota antiga */}
          <Route path="/home" element={<Navigate to="/" replace />} />
          
          {/* Rota 404 - deve ser a última */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;

