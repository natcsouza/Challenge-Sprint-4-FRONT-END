# 🚀 Instruções de Execução - Hospital Clínico

## 📋 Pré-requisitos

Antes de executar o projeto, certifique-se de ter instalado:

- **Node.js** (versão 18 ou superior)
- **npm** ou **yarn** (gerenciador de pacotes)

## 🛠️ Instalação e Execução

### 1. Instalar Dependências
```bash
npm install
```

### 2. Executar em Modo Desenvolvimento
```bash
npm run dev
```

## 📱 Funcionalidades Testáveis

### ✅ Navegação
- **Home** - Página inicial com hero section animado
- **Especialidades** - Catálogo de especialidades médicas
- **Equipe** - Apresentação da equipe (1TDSR ADS)
- **FAQ** - Perguntas frequentes com accordion interativo
- **Contato** - Formulário de contato com validação
- **Solução** - Detalhamento da solução GUIDABOT

### 🔧 Hooks Implementados
- **useState** - Gerenciamento de estado (menu mobile, FAQ, formulários)
- **useEffect** - Efeitos colaterais (scroll, animações, lifecycle)
- **useNavigate** - Navegação programática (botões de ação)
- **useForm** - Gerenciamento de formulários (React Hook Form)

### 📋 Formulários Funcionais
- **Formulário de Contato** - Validação completa com mensagens de erro
- **Newsletter** - Cadastro de newsletter no footer
- **Simulação de Agendamento** - Botões de agendamento funcionais

## 🎨 Design Responsivo

A aplicação se adapta automaticamente a diferentes tamanhos de tela:

- **📱 Mobile** (< 768px) - Menu hambúrguer, layout em coluna
- **📱 Tablet** (768px - 1024px) - Layout híbrido
- **💻 Desktop** (> 1024px) - Layout completo com sidebar

## 🧪 Testes de Funcionalidade

### 1. Navegação
- Teste todos os links do menu
- Verifique se o menu mobile funciona
- Confirme se a navegação suave está funcionando

### 2. Formulários
- Teste validação de campos obrigatórios
- Verifique mensagens de erro
- Teste envio do formulário

### 3. FAQ
- Teste abertura/fechamento dos itens
- Verifique animações suaves

### 4. Responsividade
- Teste em diferentes tamanhos de tela
- Verifique se o layout se adapta corretamente

## 🐛 Solução de Problemas

### Erro de Dependências
```bash
# Limpar cache e reinstalar
rm -rf node_modules package-lock.json
npm install
```

### Erro de Porta
```bash
# Executar em porta específica
npm run dev -- --port 3000
```

### Erro de TypeScript
```bash
# Verificar tipos
npx tsc --noEmit
```

## 📊 Scripts Disponíveis

```bash
npm run dev          # Executa em modo desenvolvimento
npm run build        # Gera build de produção
npm run preview      # Preview do build de produção
npm run lint         # Executa o linter
```

## 🎯 Pontos de Atenção

1. **Imagens da Equipe** - Substitua os placeholders por fotos reais
2. **Links Externos** - Verifique se todos os links estão funcionando
3. **Validação de Formulários** - Teste todos os campos obrigatórios
4. **Responsividade** - Teste em dispositivos reais se possível

## 📞 Suporte

Em caso de dúvidas ou problemas:

- **Rafael Malaguti** - Líder do Projeto
- **Natalia Souza** - Vendedora
- **Lincoln Roncato** - Desenvolvedor

---

**Desenvolvido com ❤️ pela equipe 1TDSR ADS**






