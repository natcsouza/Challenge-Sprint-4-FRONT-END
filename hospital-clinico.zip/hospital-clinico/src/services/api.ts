import { 
  ApiResponse, 
  PaginatedResponse, 
  QueryParams, 
  RequestConfig,
  HttpMethod,
  Paciente,
  Consulta,
  EspecialidadeAPI
} from '../types';

// URL base da API - deve ser configurada via variável de ambiente
const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080';

/**
 * Classe para gerenciar requisições HTTP à API
 */
class ApiService {
  private baseURL: string;

  constructor(baseURL: string = API_BASE_URL) {
    this.baseURL = baseURL;
  }

  /**
   * Método privado para fazer requisições HTTP
   */
  private async request<T>(
    endpoint: string,
    config: RequestConfig
  ): Promise<ApiResponse<T>> {
    try {
      const { method, headers = {}, body, params } = config;

      // Construir URL com query parameters
      let url = `${this.baseURL}${endpoint}`;
      if (params) {
        const queryString = this.buildQueryString(params);
        url += queryString ? `?${queryString}` : '';
      }

      // Configurar headers
      const requestHeaders: HeadersInit = {
        'Content-Type': 'application/json',
        ...headers,
      };

      // Configurar opções da requisição
      const requestOptions: RequestInit = {
        method,
        headers: requestHeaders,
      };

      // Adicionar body se necessário
      if (body && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
        requestOptions.body = JSON.stringify(body);
      }

      // Fazer a requisição
      const response = await fetch(url, requestOptions);

      // Verificar se a resposta é ok
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.message || `Erro na requisição: ${response.statusText}`
        );
      }

      // Parse da resposta
      const data = await response.json();

      return {
        success: true,
        data,
      };
    } catch (error) {
      // Tratamento de erros
      let errorMessage = 'Erro desconhecido ao realizar a requisição';
      
      if (error instanceof TypeError && error.message.includes('Failed to fetch')) {
        errorMessage = 'Não foi possível conectar à API. Verifique se o servidor está rodando.';
      } else if (error instanceof Error) {
        errorMessage = error.message;
      }

      return {
        success: false,
        message: errorMessage,
        errors: [errorMessage],
      };
    }
  }

  /**
   * Construir query string a partir de parâmetros
   */
  private buildQueryString(params: QueryParams): string {
    const queryParams = new URLSearchParams();
    
    if (params.page !== undefined) {
      queryParams.append('page', params.page.toString());
    }
    if (params.size !== undefined) {
      queryParams.append('size', params.size.toString());
    }
    if (params.sort) {
      queryParams.append('sort', params.sort);
    }
    if (params.search) {
      queryParams.append('search', params.search);
    }
    if (params.status) {
      queryParams.append('status', params.status);
    }

    return queryParams.toString();
  }

  // ========== CRUD PACIENTES ==========

  /**
   * GET - Listar todos os pacientes
   */
  async getPacientes(params?: QueryParams): Promise<ApiResponse<PaginatedResponse<Paciente>>> {
    return this.request<PaginatedResponse<Paciente>>('/pacientes', {
      method: 'GET',
      params,
    });
  }

  /**
   * GET - Buscar paciente por ID
   */
  async getPacienteById(id: string | number): Promise<ApiResponse<Paciente>> {
    return this.request<Paciente>(`/pacientes/${id}`, {
      method: 'GET',
    });
  }

  /**
   * POST - Criar novo paciente
   */
  async createPaciente(paciente: Omit<Paciente, 'id' | 'createdAt' | 'updatedAt'>): Promise<ApiResponse<Paciente>> {
    return this.request<Paciente>('/pacientes', {
      method: 'POST',
      body: paciente,
    });
  }

  /**
   * PUT - Atualizar paciente
   */
  async updatePaciente(
    id: string | number,
    paciente: Partial<Paciente>
  ): Promise<ApiResponse<Paciente>> {
    return this.request<Paciente>(`/pacientes/${id}`, {
      method: 'PUT',
      body: paciente,
    });
  }

  /**
   * DELETE - Deletar paciente
   */
  async deletePaciente(id: string | number): Promise<ApiResponse<void>> {
    return this.request<void>(`/pacientes/${id}`, {
      method: 'DELETE',
    });
  }

  // ========== CRUD CONSULTAS ==========

  /**
   * GET - Listar todas as consultas
   */
  async getConsultas(params?: QueryParams): Promise<ApiResponse<PaginatedResponse<Consulta>>> {
    return this.request<PaginatedResponse<Consulta>>('/consultas', {
      method: 'GET',
      params,
    });
  }

  /**
   * GET - Buscar consulta por ID
   */
  async getConsultaById(id: string | number): Promise<ApiResponse<Consulta>> {
    return this.request<Consulta>(`/consultas/${id}`, {
      method: 'GET',
    });
  }

  /**
   * POST - Criar nova consulta
   */
  async createConsulta(consulta: Omit<Consulta, 'id' | 'createdAt' | 'updatedAt'>): Promise<ApiResponse<Consulta>> {
    return this.request<Consulta>('/consultas', {
      method: 'POST',
      body: consulta,
    });
  }

  /**
   * PUT - Atualizar consulta
   */
  async updateConsulta(
    id: string | number,
    consulta: Partial<Consulta>
  ): Promise<ApiResponse<Consulta>> {
    return this.request<Consulta>(`/consultas/${id}`, {
      method: 'PUT',
      body: consulta,
    });
  }

  /**
   * DELETE - Deletar consulta
   */
  async deleteConsulta(id: string | number): Promise<ApiResponse<void>> {
    return this.request<void>(`/consultas/${id}`, {
      method: 'DELETE',
    });
  }

  // ========== CRUD ESPECIALIDADES ==========

  /**
   * GET - Listar todas as especialidades
   */
  async getEspecialidades(params?: QueryParams): Promise<ApiResponse<PaginatedResponse<EspecialidadeAPI>>> {
    return this.request<PaginatedResponse<EspecialidadeAPI>>('/especialidades', {
      method: 'GET',
      params,
    });
  }

  /**
   * GET - Buscar especialidade por ID
   */
  async getEspecialidadeById(id: string | number): Promise<ApiResponse<EspecialidadeAPI>> {
    return this.request<EspecialidadeAPI>(`/especialidades/${id}`, {
      method: 'GET',
    });
  }

  /**
   * POST - Criar nova especialidade
   */
  async createEspecialidade(especialidade: Omit<EspecialidadeAPI, 'id' | 'createdAt' | 'updatedAt'>): Promise<ApiResponse<EspecialidadeAPI>> {
    return this.request<EspecialidadeAPI>('/especialidades', {
      method: 'POST',
      body: especialidade,
    });
  }

  /**
   * PUT - Atualizar especialidade
   */
  async updateEspecialidade(
    id: string | number,
    especialidade: Partial<EspecialidadeAPI>
  ): Promise<ApiResponse<EspecialidadeAPI>> {
    return this.request<EspecialidadeAPI>(`/especialidades/${id}`, {
      method: 'PUT',
      body: especialidade,
    });
  }

  /**
   * DELETE - Deletar especialidade
   */
  async deleteEspecialidade(id: string | number): Promise<ApiResponse<void>> {
    return this.request<void>(`/especialidades/${id}`, {
      method: 'DELETE',
    });
  }
}

// Instância singleton do serviço
export const apiService = new ApiService();

// Exportar a classe para casos especiais
export default ApiService;

