import React from 'react';
import Toast from './Toast';
import { Feedback } from '../types';

interface ToastContainerProps {
  toasts: Feedback[];
  onRemove: (index: number) => void;
}

const ToastContainer: React.FC<ToastContainerProps> = ({ toasts, onRemove }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-20 right-4 z-50 space-y-2 flex flex-col items-end">
      {toasts.map((toast, index) => (
        <Toast
          key={index}
          {...toast}
          onClose={() => onRemove(index)}
        />
      ))}
    </div>
  );
};

export default ToastContainer;

