import React from 'react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-hospital-dark text-white py-16">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Logo e Descrição */}
          <div className="space-y-4">
            <div className="mb-4">
              <img 
                src="https://inradiando.com.br/wp-content/uploads/2019/10/NOVO-LOGO-HC-2022.png" 
                alt="Hospital Clínico" 
                className="h-10"
              />
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Excelência em saúde e bem-estar há mais de 20 anos. Comprometidos com atendimento humanizado e tecnologia de ponta.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center hover:bg-hospital-orange transition-colors duration-300">
                <i className="fab fa-facebook-f"></i>
              </a>
              <a 
                href="https://www.instagram.com/hospitalhcfmusp/?hl=pt_BR" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center hover:bg-hospital-orange transition-colors duration-300"
              >
                <i className="fab fa-instagram"></i>
              </a>
              <a 
                href="https://www.youtube.com/@hospitaldasclinicasdafmusp3623" 
                target="_blank" 
                rel="noopener noreferrer"
                className="w-10 h-10 bg-gray-700 rounded-full flex items-center justify-center hover:bg-hospital-orange transition-colors duration-300"
              >
                <i className="fab fa-youtube"></i>
              </a>
            </div>
          </div>

          {/* Links Rápidos */}
          <div>
            <h3 className="text-xl font-bold mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li><a href="#inicio" className="text-gray-300 hover:text-white transition-colors duration-300">Início</a></li>
              <li><a href="#especialidades" className="text-gray-300 hover:text-white transition-colors duration-300">Especialidades</a></li>
              <li><a href="#equipe" className="text-gray-300 hover:text-white transition-colors duration-300">Equipe</a></li>
              <li><a href="#faq" className="text-gray-300 hover:text-white transition-colors duration-300">Perguntas Frequentes</a></li>
              <li><a href="#contato" className="text-gray-300 hover:text-white transition-colors duration-300">Contato</a></li>
            </ul>
          </div>

          {/* Serviços */}
          <div>
            <h3 className="text-xl font-bold mb-4">Serviços</h3>
            <ul className="space-y-2">
              <li><a href="#contato" className="text-gray-300 hover:text-white transition-colors duration-300">Consultas</a></li>
              <li><a href="#especialidades" className="text-gray-300 hover:text-white transition-colors duration-300">Exames</a></li>
              <li><a href="#contato" className="text-gray-300 hover:text-white transition-colors duration-300">Cirurgias</a></li>
              <li><a href="#contato" className="text-gray-300 hover:text-white transition-colors duration-300">Pronto-socorro</a></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-xl font-bold mb-4">Newsletter</h3>
            <p className="text-gray-300 text-sm mb-4">
              Assine nossa newsletter para receber novidades e dicas de saúde.
            </p>
            <form className="space-y-3">
              <input 
                type="email" 
                placeholder="Seu email" 
                className="w-full px-4 py-2 bg-gray-700 border border-gray-600 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-hospital-orange"
                required 
              />
              <button 
                type="submit" 
                className="btn btn-primary w-full"
              >
                Assinar
              </button>
            </form>
          </div>
        </div>

        {/* Footer Bottom */}
        <div className="border-t border-gray-700 pt-8 text-center">
          <p className="text-gray-400 text-sm">
            &copy; {currentYear} Hospital Clínico. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

