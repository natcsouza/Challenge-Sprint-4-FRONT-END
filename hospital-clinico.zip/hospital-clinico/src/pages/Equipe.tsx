import React from 'react';
import Card from '../components/Card';
import { teamMembers } from '../data/mockData';

const Equipe: React.FC = () => {
  return (
    <div className="pt-20">
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="section-title">Nossa Equipe</h1>
            <p className="section-subtitle">1TDSR ADS</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {teamMembers.map((member) => (
              <Card key={member.id} className="text-center">
                <div className="p-6">
                  <img 
                    src={member.image} 
                    alt={member.name}
                    className="w-32 h-32 rounded-full object-cover mx-auto mb-4 border-4 border-gray-200"
                  />
                  <h3 className="text-xl font-bold text-hospital-blue mb-2">
                    {member.name}
                  </h3>
                  <p className="text-hospital-orange font-semibold mb-2">
                    {member.role}
                  </p>
                  <p className="text-gray-600 text-sm mb-4">
                    RM: {member.rm}
                  </p>
                  <div className="flex justify-center space-x-4">
                    {member.linkedin && (
                      <a 
                        href={member.linkedin} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="w-10 h-10 bg-hospital-blue text-white rounded-full flex items-center justify-center hover:bg-hospital-orange transition-colors duration-300"
                      >
                        <i className="fab fa-linkedin-in"></i>
                      </a>
                    )}
                    {member.github && (
                      <a 
                        href={member.github} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="w-10 h-10 bg-hospital-blue text-white rounded-full flex items-center justify-center hover:bg-hospital-orange transition-colors duration-300"
                      >
                        <i className="fab fa-github"></i>
                      </a>
                    )}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Equipe;






