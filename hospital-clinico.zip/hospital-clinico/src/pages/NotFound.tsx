import React from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../components/Button';

const NotFound: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 pt-20 px-4">
      <div className="text-center max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-9xl font-bold text-hospital-blue mb-4">404</h1>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
            Página não encontrada
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Desculpe, a página que você está procurando não existe ou foi movida.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button
            onClick={() => navigate('/')}
            variant="primary"
            size="large"
          >
            <i className="fas fa-home mr-2"></i>
            Voltar para Home
          </Button>
          <Button
            onClick={() => navigate(-1)}
            variant="secondary"
            size="large"
          >
            <i className="fas fa-arrow-left mr-2"></i>
            Voltar
          </Button>
        </div>

        <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4 text-left">
          <div className="p-4 bg-white rounded-lg shadow">
            <h3 className="font-semibold text-hospital-blue mb-2">Início</h3>
            <button
              onClick={() => navigate('/')}
              className="text-gray-600 hover:text-hospital-orange transition-colors"
            >
              Página inicial
            </button>
          </div>
          <div className="p-4 bg-white rounded-lg shadow">
            <h3 className="font-semibold text-hospital-blue mb-2">Especialidades</h3>
            <button
              onClick={() => navigate('/especialidades')}
              className="text-gray-600 hover:text-hospital-orange transition-colors"
            >
              Ver especialidades
            </button>
          </div>
          <div className="p-4 bg-white rounded-lg shadow">
            <h3 className="font-semibold text-hospital-blue mb-2">Contato</h3>
            <button
              onClick={() => navigate('/contato')}
              className="text-gray-600 hover:text-hospital-orange transition-colors"
            >
              Fale conosco
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotFound;

