import React from 'react';
import Card from '../components/Card';

const Solucao: React.FC = () => {
  return (
    <div className="pt-20">
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h1 className="section-title">Solução</h1>
            <p className="section-subtitle">
              Objetivo principal: reduzir a taxa de absenteísmo de 20% para menos de 10%.
            </p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            <Card>
              <div className="p-8">
                <h2 className="text-2xl font-bold text-hospital-blue mb-6">GUIDABOT</h2>
                
                <div className="space-y-6 text-gray-700 leading-relaxed">
                  <div>
                    <h3 className="text-lg font-semibold text-hospital-blue mb-3">
                      Problemas identificados no IMREA (levantados na palestra):
                    </h3>
                    <ul className="list-disc list-inside space-y-2 ml-4">
                      <li>Alta taxa de faltas e desistências de pacientes.</li>
                      <li>Dificuldade de entendimento e uso do celular para interações com saúde digital.</li>
                      <li>Baixa escolaridade e analfabetismo funcional.</li>
                      <li>Falta de acompanhamento familiar.</li>
                      <li>Cadastros incompletos e falhas na comunicação.</li>
                      <li>Pouco uso de recursos de acessibilidade digital.</li>
                      <li>Dificuldade no acesso e uso das teleconsultas.</li>
                    </ul>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-hospital-blue mb-3">
                      Nossa Solução:
                    </h3>
                    <p className="mb-4">
                      A GUIDA é uma assistente digital humanizada que atua como elo entre paciente, acompanhante e equipe do IMREA. Ela funciona principalmente via WhatsApp (bot), com integração a uma interface web simples e responsiva (mini site que simula um app), e é apoiada por vídeos acessíveis, notificações automatizadas e um modelo de comunicação inteligente.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-lg font-semibold text-hospital-blue mb-3">
                      Componentes da solução:
                    </h3>
                    
                    <div className="space-y-4">
                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-hospital-blue mb-2">🧠 1. Cadastro Inteligente pelo WhatsApp com Acompanhante Obrigatório</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>Chatbot GUIDAbot inicia o processo.</li>
                          <li>Cadastro só é concluído com a inclusão de pelo menos 1 acompanhante com telefone válido.</li>
                          <li>Validação do acompanhante via SMS ou WhatsApp.</li>
                          <li>O cadastro gera um token (chave temporária) para liberar o acesso ao sistema.</li>
                        </ul>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-hospital-blue mb-2">📆 2. Agendamento guiado com validação dupla (Paciente + Acompanhante)</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>Após cadastro, o paciente pode solicitar triagem e agendar consultas.</li>
                          <li>Ao tentar confirmar o agendamento: GUIDAbot redireciona para uma página externa.</li>
                          <li>Ambos (paciente e acompanhante) precisam assistir a um vídeo obrigatório de instruções.</li>
                          <li>Assinar (digitalmente) o termo de consentimento LGPD.</li>
                          <li>Confirmar juntos a data e hora da consulta.</li>
                        </ul>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-hospital-blue mb-2">🔗 3. Integração com ferramentas externas e agendamento de teleconsultas</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>Após a confirmação, o sistema reserva um link de teleconsulta exclusivo.</li>
                          <li>Bloqueia acesso simultâneo ao link em horários não permitidos.</li>
                          <li>Envia o link com 48h e 3h de antecedência via WhatsApp.</li>
                        </ul>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-hospital-blue mb-2">🔁 4. Lembretes e Confirmação Automatizada</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>Sistema em Python envia lembretes automáticos para o paciente confirmar presença.</li>
                          <li>Caso o paciente não responda, GUIDAbot notifica o acompanhante.</li>
                        </ul>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-hospital-blue mb-2">📱 5. Mini site responsivo (Simula app)</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>Criado em HTML/CSS/JS responsivo.</li>
                          <li>Interface acessível: botões grandes, texto simples.</li>
                          <li>Avatar amigável da GUIDAbot, com fala humanizada.</li>
                          <li>Recursos integrados: Calendário de consultas, Acesso a justificativas de faltas, Upload de documentos, Acesso a receitas e encaminhamentos, Ferramenta de conversão de texto para áudio e vice-versa.</li>
                        </ul>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-hospital-blue mb-2">🎯 6. Integração com sistema de dados do IMREA</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>Sistema recebe os dados e apenas redireciona para nuvem do IMREA (InCor, por exemplo).</li>
                          <li>Não armazenamos dados sensíveis localmente, o que reduz custo e risco jurídico.</li>
                        </ul>
                      </div>

                      <div className="bg-gray-50 p-4 rounded-lg">
                        <h4 className="font-semibold text-hospital-blue mb-2">🎯 7. Campanha de sensibilização dos acompanhantes</h4>
                        <ul className="list-disc list-inside space-y-1 text-sm">
                          <li>Mensagens prontas enviadas pelas UBS.</li>
                          <li>Cartaz com QR Code para onboarding pelo WhatsApp.</li>
                          <li>Acompanhante envolvido em todos os processos.</li>
                        </ul>
                      </div>
                    </div>
                  </div>

                  <div className="border-t pt-6">
                    <h3 className="text-lg font-semibold text-hospital-blue mb-3">
                      Impactos esperados:
                    </h3>
                    <ul className="list-disc list-inside space-y-2">
                      <li>Redução drástica da taxa de absenteísmo em 10%.</li>
                      <li>Aumento do engajamento de acompanhantes.</li>
                      <li>Inclusão digital com foco em acessibilidade.</li>
                      <li>Comunicação direta e empática com o paciente.</li>
                      <li>Cadastro 100% validado e informações padronizadas.</li>
                      <li>Otimização de recursos do IMREA e atendimento mais eficaz.</li>
                    </ul>
                  </div>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Solucao;






